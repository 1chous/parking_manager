--
-- PostgreSQL database dump
--

\restrict TRYlZ7wXsIQJ89GDvOoTPpsX4Kn4Cs2pC6GWQhSIvRj82eenSt0lphEdCPJZKs8

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: park_zone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.park_zone (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    capacity integer NOT NULL,
    cost integer NOT NULL,
    image_url text
);


ALTER TABLE public.park_zone OWNER TO postgres;

--
-- Name: parking_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parking_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parkingzone_id uuid NOT NULL,
    vehicle_plate text NOT NULL,
    entry_time timestamp without time zone NOT NULL,
    exit_time timestamp without time zone,
    is_payed boolean NOT NULL
);


ALTER TABLE public.parking_session OWNER TO postgres;

--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	create park zone table	SQL	V1__create_park_zone_table.sql	-717222072	postgres	2026-07-07 19:19:02.245356	36	t
2	2	add new data	SQL	V2__add_new_data.sql	-1535893566	postgres	2026-07-07 19:19:02.450997	11	t
\.


--
-- Data for Name: park_zone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.park_zone (id, name, capacity, cost, image_url) FROM stdin;
dee63bb1-d193-4f2d-939f-9feac5efb4c1	Парковка 1	100	10	image/first_parking.jpg
c4fe415e-deab-4c3d-969f-490a0be56a10	Парковка 2	50	20	image/second_parking.jpg
\.


--
-- Data for Name: parking_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parking_session (id, parkingzone_id, vehicle_plate, entry_time, exit_time, is_payed) FROM stdin;
267caade-a542-49b0-9e01-5a28a8ef2dec	dee63bb1-d193-4f2d-939f-9feac5efb4c1	string	2021-01-01 09:00:00	2021-01-01 10:00:00	t
694c9cf3-958d-43fb-bbf8-5a25ad68b8fb	c4fe415e-deab-4c3d-969f-490a0be56a10	string	2021-01-01 10:00:00	2026-07-07 19:25:37.526	t
e75d82ad-9537-45b2-b589-72d09fa03129	dee63bb1-d193-4f2d-939f-9feac5efb4c1	A123AA667	2026-07-07 19:30:49.343352	\N	f
\.


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: park_zone park_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.park_zone
    ADD CONSTRAINT park_zone_pkey PRIMARY KEY (id);


--
-- Name: parking_session parking_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parking_session
    ADD CONSTRAINT parking_session_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: parking_session parking_session_parkingzone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parking_session
    ADD CONSTRAINT parking_session_parkingzone_id_fkey FOREIGN KEY (parkingzone_id) REFERENCES public.park_zone(id);


--
-- PostgreSQL database dump complete
--

\unrestrict TRYlZ7wXsIQJ89GDvOoTPpsX4Kn4Cs2pC6GWQhSIvRj82eenSt0lphEdCPJZKs8

